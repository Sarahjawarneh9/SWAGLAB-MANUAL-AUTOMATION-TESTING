﻿
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Text;


namespace FinalProject
{
    internal class Excel
    {
        Application excel1 = new Application();
        Workbook wb;
        Worksheet ws;
        //C:\Users\Admin\OneDrive\Desktop\Automation testing.xlsx
        public void OpenExcel(string path, int sheet)
        {
            wb = excel1.Workbooks.Open(path);
            ws = wb.Worksheets[sheet];

        }
        public string ReadExcel(int c, int r)
        {
            return ws.Cells[c][r].value;
        }

        public void WriteExcel(int c, int r , string text)
        {
            
            ws.Cells[c][r].value = text;
        }

        public void Save()
        {
            wb.Save();
        }

        public void SaveAs(string path)
        {
            wb.SaveAs();
        }

        public void CloseExcel()
        {
            excel1.Workbooks.Close();
        }
    }
}
