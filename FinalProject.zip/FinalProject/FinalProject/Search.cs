﻿
using Aspose.Cells;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace FinalProject
{
    
    [TestClass]
    public class Search
    {
        public static int s =1 ;
        public static void SearchSWAG(string user, string password)
        {
            TestSetup.NavigateToURL(TestSetup.driver, TestSetup.url);
            System.Threading.Thread.Sleep(4000);

            IWebElement usernameInput = TestSetup.driver.FindElement(By.XPath("//div/form/div/input[@id='user-name']"));
            TestSetup.HighlightElement(TestSetup.driver, usernameInput);
            usernameInput.SendKeys(user);
            System.Threading.Thread.Sleep(1000);

            IWebElement passwordInput = TestSetup.driver.FindElement(By.XPath("//div/form/div/input[@id='password']"));
            TestSetup.HighlightElement(TestSetup.driver, passwordInput);
            passwordInput.SendKeys(password);
            System.Threading.Thread.Sleep(1000);

            IWebElement loginInput = TestSetup.driver.FindElement(By.XPath("//div/form/input[@id='login-button']"));
            TestSetup.HighlightElement(TestSetup.driver, loginInput);
            loginInput.Click();

            System.Threading.Thread.Sleep(5000);

            IWebElement checkElement = TestSetup.driver.FindElement(By.XPath("//div/div/span[.='Products']"));
            TestSetup.HighlightElement(TestSetup.driver, checkElement);
            string text = checkElement.GetAttribute("innerText");
            if (text == "Products")
            {
                Console.WriteLine("User can logged in successfully ");
            }

        }

        public void excelStandard(int testId, string description, string status, string testData)
        {
            
            Workbook workbook = new Workbook(@"C:\Users\Admin\OneDrive\Desktop\Final Project\Automation testing.xlsx");

            // Accessing the first worksheet in the Excel file
            Worksheet worksheet = workbook.Worksheets[0];
            int maxdata = worksheet.Cells.MaxDataRow;
            worksheet.Cells.InsertRow(maxdata + 1);

            worksheet.Cells[maxdata + 1, 0].Value = testId;
            worksheet.Cells[maxdata + 1, 1].Value = description;
            worksheet.Cells[maxdata + 1, 2].Value = status;
            worksheet.Cells[maxdata + 1, 3].Value = testData;
            // Saving the modified Excel file
            workbook.Save(@"C:\Users\Admin\OneDrive\Desktop\Final Project\Automation testing.xlsx");
        }

        public void excelProblem(int testId, string description, string status, string testData, string errorMessage )
        {
            
            Workbook workbook = new Workbook(@"C:\Users\Admin\OneDrive\Desktop\Final Project\Automation testing.xlsx");

            Worksheet worksheet = workbook.Worksheets[0];
            int maxdata = worksheet.Cells.MaxDataRow;
            worksheet.Cells.InsertRow(maxdata + 1);
            worksheet.Cells[maxdata + 1, 0].Value = testId;
            worksheet.Cells[maxdata + 1, 1].Value = description;
            worksheet.Cells[maxdata + 1, 2].Value = status;
            worksheet.Cells[maxdata + 1, 3].Value = testData;
            worksheet.Cells[maxdata + 1, 4].Value = errorMessage;

            // Saving the modified Excel file
            workbook.Save(@"C:\Users\Admin\OneDrive\Desktop\Final Project\Automation testing.xlsx");
        }

        [TestMethod]
        public void StandardSearchNameAtoZ()
        {

            SearchSWAG("standard_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='az']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/a/div[@class='inventory_item_name']"));


            string[] names = new string[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {

                names[i] = webElements[i].GetAttribute("innerText");

            }

            string[] sorted = names.OrderBy(x => x).ToArray();

            //Console.WriteLine(String.Join(", ", sorted));

            //Console.WriteLine(String.Join(", ", names));

            for (int i = 0; i < sorted.Length; i++)
            {

                if (i == sorted.Length - 1)
                {
                    Console.WriteLine("Passed");
                    break;
                }

                if (sorted[i] == names[i])
                    continue;


                else
                {
                    Console.WriteLine("Failed");
                    Console.WriteLine("The item is not sorting from A to Z ");
                    break;
                }
                
            }
            excelStandard(s++, " verify whether the searching Name(A to Z) is resorting or not", "PASS", "username : standard_user && password: secret_sauce");

        }

        [TestMethod]
        public void ProblemSearchNameAtoZ()
        {
            SearchSWAG("problem_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='az']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/a/div[@class='inventory_item_name']"));


            string[] names = new string[webElements.Count];





            for (int i = 0; i < webElements.Count; i++)
            {

                names[i] = webElements[i].GetAttribute("innerText");

            }

            string[] sorted = names.OrderBy(x => x).ToArray();

            //Console.WriteLine(String.Join(", ", sorted));

            //Console.WriteLine(String.Join(", ", names));

            for (int i = 0; i < sorted.Length; i++)
            {

                if (i == sorted.Length - 1)
                {
                    Console.WriteLine("Passed");
                    break;
                }

                if (sorted[i] == names[i])
                    continue;


                else
                {
                    Console.WriteLine("Failed");
                    Console.WriteLine("The item is not sorting from A to Z ");
                    break;
                }
            }
            excelStandard(s++, " verify whether the searching Name(A to Z) is resorting or not", "PASS", "username : problem_user && password: secret_sauce");

        }

        [TestMethod]
        public void StandardSearchNameZtoA()
        {
            SearchSWAG("standard_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='za']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/a/div[@class='inventory_item_name']"));


            string[] names = new string[webElements.Count];





            for (int i = 0; i < webElements.Count; i++)
            {

                names[i] = webElements[i].GetAttribute("innerText");

            }

            string[] sorted = names.OrderBy(x => x).ToArray();
            string[] revers = new string[sorted.Length];
            for (int i = 0, j = sorted.Length - 1; i < sorted.Length; i++, j--)
            {
                revers[i] = sorted[j];
            }

            //Console.WriteLine(String.Join(", ", names));

            //Console.WriteLine(String.Join(", ", revers));

            for (int i = 0; i < sorted.Length; i++)
            {

                if (i == sorted.Length - 1)
                {
                    Console.WriteLine("Passed");
                    break;
                }

                if (revers[i] == names[i])
                    continue;


                else
                {
                    Console.WriteLine("Failed");
                    Console.WriteLine("The item is not sorting from Z to A ");
                    break;
                }
            }
            excelStandard(s++, " verify whether the searching Name(Z to A) is resorting or not", "PASS", "username : standard_user && password: secret_sauce");
        }

        [TestMethod]
        public void ProblemSearchNameZtoA()
        {
            SearchSWAG("problem_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='za']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/a/div[@class='inventory_item_name']"));


            string[] names = new string[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {

                names[i] = webElements[i].GetAttribute("innerText");

            }

            string[] sorted = names.OrderBy(x => x).ToArray();
            string[] revers = new string[sorted.Length];
            for (int i = 0, j = sorted.Length - 1; i < sorted.Length; i++, j--)
            {
                revers[i] = sorted[j];
            }

            //Console.WriteLine(String.Join(", ", names));

            //Console.WriteLine(String.Join(", ", revers));

            for (int i = 0; i < sorted.Length; i++)
            {

                if (i == sorted.Length - 1)
                {
                    Console.WriteLine("Passed");
                    break;
                }

                if (revers[i] == names[i])
                    continue;


                else
                {
                    Console.WriteLine("Failed");
                    Console.WriteLine("The item is not sorting from Z to A ");
                    break;
                }
            }
            excelProblem(s++, " verify whether the searching Name(Z to A)  is resorting or not", "FAILED", " username: problem_user && pasword: secret_sauce", "  When we sorting choose the option  Name(Z to A)  the sorting is not working and it is not doing anything ");
        }

        [TestMethod]
        public void StandardSearchPriceLowtoHigh()
        {
            SearchSWAG("standard_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='lohi']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/div[@class='inventory_item_price']"));

            double[] prices = new double[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {
                prices[i] = Convert.ToDouble(webElements[i].GetAttribute("innerText").Trim('$', ' '));
            }

            for (int i = 0; i < prices.Length; i++)
            {
                if (i == prices.Length - 1)
                {
                    {
                        Console.WriteLine("PASSED");
                        break;
                    }
                }
                if (prices[i] <= prices[i + 1])
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("FAILED!!!");
                    Console.WriteLine("The item is greater than the next item");
                    break;
                }
            }
            excelStandard(s++, " verify whether the searching Price(low to high) is resorting or not", "PASS", "username : standard_user && password: secret_sauce");

        }

        [TestMethod]
        public void ProblemSearchPriceLowtoHigh()
        {
            SearchSWAG("problem_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='lohi']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/div[@class='inventory_item_price']"));

            double[] prices = new double[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {
                prices[i] = Convert.ToDouble(webElements[i].GetAttribute("innerText").Trim('$', ' '));
            }

            for (int i = 0; i < prices.Length; i++)
            {
                if (i == prices.Length - 1)
                {
                    {
                        Console.WriteLine("PASSED");
                        break;
                    }
                }
                if (prices[i] <= prices[i + 1])
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("FAILED!!!");
                    Console.WriteLine("The item is greater than the next item");
                    break;
                }
            }
            excelProblem(s++, " verify whether the searching Price(low to high)  is resorting or not", "FAILED", " username: problem_user && pasword: secret_sauce", "  When we sorting choose the option  Price(low to high)  the sorting is not working and it is not doing anything ");
        }

        [TestMethod]
        public void StandardSearchPriceHightoLow()
        {
            SearchSWAG("standard_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='hilo']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/div[@class='inventory_item_price']"));

            double[] prices = new double[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {
                prices[i] = Convert.ToDouble(webElements[i].GetAttribute("innerText").Trim('$', ' '));
            }

            for (int i = 0; i < prices.Length; i++)
            {
                if (i == prices.Length - 1)
                {
                    {
                        Console.WriteLine("PASSED");
                        break;
                    }
                }
                if (prices[i] >= prices[i + 1])
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("FAILED!!!");
                    Console.WriteLine("The item is not greater than the next item");
                    break;
                }
            }
            excelStandard(s++, " verify whether the searching Price(high to low) is resorting or not", "PASS", "username : standard_user && password: secret_sauce");

        }

        [TestMethod]
        public void ProblemSearchPriceHightoLow()
        {
            SearchSWAG("problem_user", "secret_sauce");

            IWebElement searchinput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select[@class='product_sort_container']"));
            TestSetup.HighlightElement(TestSetup.driver, searchinput);
            searchinput.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement optioninput = TestSetup.driver.FindElement(By.XPath("//div/div/span/select/option[@value='hilo']"));
            TestSetup.HighlightElement(TestSetup.driver, optioninput);
            optioninput.Click();
            System.Threading.Thread.Sleep(5000);

            ReadOnlyCollection<IWebElement> webElements = TestSetup.driver.FindElements(By.XPath("//div/div[@class='inventory_item_price']"));

            double[] prices = new double[webElements.Count];

            for (int i = 0; i < webElements.Count; i++)
            {
                prices[i] = Convert.ToDouble(webElements[i].GetAttribute("innerText").Trim('$', ' '));
            }

            for (int i = 0; i < prices.Length; i++)
            {
                if (i == prices.Length - 1)
                {
                    {
                        Console.WriteLine("PASSED");
                        break;
                    }
                }
                if (prices[i] >= prices[i + 1])
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("FAILED!!!");
                    Console.WriteLine("The item is not greater than the next item");
                    break;
                }
            }
            excelProblem(s++, " verify whether the searching Price(high to low)  is resorting or not", "FAILED", " username: problem_user && pasword: secret_sauce", "  When we sorting choose the option  Price(high to low)  the sorting is not working and it is not doing anything ");
        }
    }
}
