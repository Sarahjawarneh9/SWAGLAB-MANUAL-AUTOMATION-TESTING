﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProject
{
    internal class TestSetup
    {
        public static IWebDriver driver = new ChromeDriver();
        public static string url = "https://www.saucedemo.com/";

        public static void NavigateToURL(IWebDriver driver, string url)
        {

            driver.Manage().Window.Size = new System.Drawing.Size(1000, 1000);
            driver.Navigate().GoToUrl(url);
        }

        public static void HighlightElement(IWebDriver driver, IWebElement element)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].setAttribute('style', 'background : lightblue ! important')", element);
            System.Threading.Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].setAttribute('style', 'border : solid 1px white ! important')", element);
        }
    }
}
