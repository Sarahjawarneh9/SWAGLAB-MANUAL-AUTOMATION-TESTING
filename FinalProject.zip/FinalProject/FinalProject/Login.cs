﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProject
{
    internal class Login
    {
        public static void PositiveLogin(string email, string password)
        {
            TestSetup.NavigateToURL(TestSetup.driver, TestSetup.url);

            System.Threading.Thread.Sleep(4000);

            IWebElement loginBtn = TestSetup.driver.FindElement(By.XPath("//div/a[.='Login']"));
            TestSetup.HighlightElement(TestSetup.driver, loginBtn);
            loginBtn.Click();
            System.Threading.Thread.Sleep(1000);

            IWebElement emailInput = TestSetup.driver.FindElement(By.XPath("//div/input[@name='Email']"));
            TestSetup.HighlightElement(TestSetup.driver, emailInput);
            emailInput.SendKeys(email);
            System.Threading.Thread.Sleep(1000);

            IWebElement passwordInput = TestSetup.driver.FindElement(By.XPath("//div/input[@name='Password']"));
            TestSetup.HighlightElement(TestSetup.driver, passwordInput);
            passwordInput.SendKeys(password);
            System.Threading.Thread.Sleep(1000);

            IWebElement loginInput = TestSetup.driver.FindElement(By.XPath("//div/input[@type='submit']"));
            TestSetup.HighlightElement(TestSetup.driver, loginInput);
            loginInput.Click();

            System.Threading.Thread.Sleep(5000);

            IWebElement checkElement = TestSetup.driver.FindElement(By.XPath("//div/h1[.='I am a user']"));
            TestSetup.HighlightElement(TestSetup.driver, checkElement);
            string text = checkElement.GetAttribute("innerText");
            if (text == "I am a user")
            {
                Console.WriteLine("User can logged in successfully ");
            }
            
        }
        [TestMethod]
        public void RunPositiveLogin()
        {
            Excel ex = new Excel();
            ex.OpenExcel(@"C:\Users\Admin\OneDrive\Documents\Book1.xlsx", 1);
            Random rnd = new Random();
            int row = rnd.Next(2, 12);
            PositiveLogin(ex.ReadExcel(5, row), ex.ReadExcel(7, row));
            ex.CloseExcel();
        }

    }
}
